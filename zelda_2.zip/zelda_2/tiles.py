import pygame 
from settings import * 
from support import import_folder
from random import choice

class LargeObject(pygame.sprite.Sprite):
	def __init__(self,surface,x,y,*groups):
		super().__init__(groups)
		self.image = surface
		self.rect = self.image.get_rect(topleft = (x,y - tile_size))
		self.hitbox = self.rect.inflate(0,-60)

class Grass(pygame.sprite.Sprite):
	def __init__(self,x,y,*groups):
		super().__init__(groups)
		graphics = import_folder('../graphics/Grass')

		self.image = choice(graphics)
		self.rect = self.image.get_rect(topleft = (x,y))
		self.hitbox = self.rect.inflate(0,-20)

class InvisibleBlock(pygame.sprite.Sprite):
	def __init__(self,x,y,group):
		super().__init__(group)
		self.image = pygame.Surface((tile_size,tile_size))
		self.rect = self.image.get_rect(topleft = (x,y))
		self.hitbox = self.rect

class Floor(pygame.sprite.Sprite):
	def __init__(self,surface,x,y,group):
		super().__init__(group)
		self.image = surface
		self.rect = self.image.get_rect(topleft = (x,y))
		self.floor = True
