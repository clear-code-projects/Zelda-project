import pygame, sys
from settings import *
from player import Player
from tiles import LargeObject, Floor, InvisibleBlock, Grass
from debug import debug
from support import import_csv_layout, import_cut_graphic, import_folder

class Level:
	def __init__(self):

		# general 
		self.display_surface = pygame.display.get_surface()

		# sprite group setup
		self.visible_sprites = YSortCameraGroup()
		self.obstacle_sprites = pygame.sprite.Group()
		
		# sprites
		self.create_floor()
		self.create_boundaries()
		self.create_grass()
		self.create_large_objects()
		self.place_player_enemies()

	def create_floor(self):

		# csv import  
		floor_layout = import_csv_layout('../map/map_Floor.csv')
		
		# graphics import
		floor_graphics = import_cut_graphic('../graphics/Tiles/Floor.png')

		# creating the main surface 
		height = len(floor_layout) * tile_size
		width = len(floor_layout[0]) * tile_size
		walkable_surf = pygame.Surface((width,height))

		# for loop to place graphics
		for row_index, row in enumerate(floor_layout):
			for col_index, col in enumerate(row):
				x = col_index * tile_size
				y = row_index * tile_size
				floor_piece = floor_graphics[int(col)]
				walkable_surf.blit(floor_piece,(x,y))

		# turning the walkable surface into a sprite 
		walkable_ground = Floor(walkable_surf,0,0,self.visible_sprites)

	def create_boundaries(self):

		# csv import 
		boundary_layout = import_csv_layout('../map/map_FloorBlocks.csv')

		for row_index, row in enumerate(boundary_layout):
			for col_index, col in enumerate(row):
				if col != '-1':
					x = col_index * tile_size
					y = row_index * tile_size
					InvisibleBlock(x,y,self.obstacle_sprites)

	def create_grass(self):

		# csv import 
		grass_layout = import_csv_layout('../map/map_Grass.csv')

		for row_index, row in enumerate(grass_layout):
			for col_index, col in enumerate(row):
				if col != '-1':
					x = col_index * tile_size
					y = row_index * tile_size
					Grass(x,y,self.visible_sprites, self.obstacle_sprites)

	def create_large_objects(self):

		# csv import 
		object_layout = import_csv_layout('../map/map_LargeObjects.csv')
		object_graphics = import_folder('../graphics/LargeObjects')

		for row_index, row in enumerate(object_layout):
			for col_index, col in enumerate(row):
				if col != '-1':
					x = col_index * tile_size
					y = row_index * tile_size
					surf = object_graphics[int(col)]
					LargeObject(surf,x,y,self.visible_sprites, self.obstacle_sprites)
	
	def place_player_enemies(self):

		entity_layout = import_csv_layout('../map/map_Entities.csv')
		for row_index, row in enumerate(entity_layout):
			for col_index, col in enumerate(row):
				if col == '394':
					x = col_index * tile_size
					y = row_index * tile_size
					self.player = Player(x,y,self)

	def player_attack(self):
		print('attack')


	def run(self):
		self.visible_sprites.y_sorted_camera_draw(self.player) 
		self.visible_sprites.update()
		

class YSortCameraGroup(pygame.sprite.Group):
	def __init__(self):
		super().__init__()
		self.display_surface = pygame.display.get_surface()
		self.half_width = self.display_surface.get_size()[0] // 2
		self.half_height = self.display_surface.get_size()[1] // 2
		self.offset = pygame.math.Vector2(0,0)

	def y_sorted_camera_draw(self,player):
		
		# getting the offset
		self.offset.x = player.rect.centerx - self.half_width
		self.offset.y = player.rect.centery - self.half_height

		# drawing only the floor
		floor = [sprite for sprite in self.sprites() if hasattr(sprite,'floor')][0]
		floor_offset_rect = floor.rect.topleft - self.offset
		self.display_surface.blit(floor.image, floor_offset_rect)

		# drawing all other sprites
		sprites = [sprite for sprite in self.sprites() if not hasattr(sprite,'floor')]
		for sprite in sorted(sprites, key = lambda sprite: sprite.rect.centery):

			offset_rect  = sprite.rect.topleft - self.offset
			self.display_surface.blit(sprite.image, offset_rect)

