import pygame 
from settings import *
from support import import_folder

class Player(pygame.sprite.Sprite):
	def __init__(self,x,y,game):
		
		# general
		super().__init__(game.visible_sprites)
		self.game = game
		
		# display
		self.import_player_assets()
		self.frame_index = 0
		self.animation_speed = 0.15
		self.status = 'down'
		self.image = self.animations[self.status][self.frame_index]
		
		# movement
		self.rect = self.image.get_rect(topleft = (x,y))
		self.direction = pygame.math.Vector2()
		self.speed = 6
		self.attacking = False

		# collision
		self.hitbox = self.rect.copy().inflate(-6,-26)

	def import_player_assets(self):
		character_path = '../graphics/player/'
		self.animations = {'up': [],'down': [],'left': [],'right': [],
						   'idle_right':[],'idle_left':[],'idle_up':[],'idle_down':[],
						   'attack_right':[],'attack_left':[],'attack_up':[],'attack_down':[]}

		for animation in self.animations.keys():
			full_path = character_path + animation
			self.animations[animation] = import_folder(full_path)

	def input(self):
		keys = pygame.key.get_pressed()
		if keys[pygame.K_UP]:
			self.direction.y = -1
			self.status = 'up'
		elif keys[pygame.K_DOWN]:
			self.direction.y = 1
			self.status = 'down'
		else:
			self.direction.y = 0

		if keys[pygame.K_RIGHT]:
			self.direction.x = 1
			self.status = 'right'
		elif keys[pygame.K_LEFT]:
			self.direction.x = -1
			self.status = 'left'
		else:
			self.direction.x = 0

		# attack input
		if keys[pygame.K_SPACE] and not self.attacking:
			self.attacking = True
			self.attack_time = pygame.time.get_ticks()
			

		# idle status
		if self.direction.x == 0 and self.direction.y == 0:
			if not 'idle' in self.status and not 'attack' in self.status:
				self.status = 'idle_' + self.status

		# attack status
		if self.attacking:
			self.direction.x = 0
			self.direction.y = 0
			if not 'attack' in self.status:
				if 'idle' in self.status:
					self.status = 'attack_' + self.status.replace('idle_','')
				else:
					self.status = 'attack_' + self.status
		else: 
			if 'attack' in self.status:
				self.status = self.status.replace('attack_','')

	def attack_cooldown(self):
		if self.attacking:
			current_time = pygame.time.get_ticks()
			if current_time - self.attack_time >= 400:
				self.attacking = False
				

	def animate(self):
		animation = self.animations[self.status]

		# loop over frame index 
		self.frame_index += self.animation_speed
		if self.frame_index >= len(animation):
			self.frame_index = 0
		
		# set the image 
		self.image = animation[int(self.frame_index)]
		self.rect = self.image.get_rect(center = self.hitbox.center)

	def movement(self):

		# normalize vector
		if self.direction.magnitude() != 0: 
			self.direction = self.direction.normalize()
		
		# apply movement
		self.hitbox.x += self.direction.x * self.speed
		self.collision('horizontal')
		self.hitbox.y += self.direction.y * self.speed
		self.collision('vertical')
		self.rect.center = self.hitbox.center

	def collision(self,direction):
		if direction == 'horizontal':
			for sprite in self.game.obstacle_sprites:
				if sprite.hitbox.colliderect(self.hitbox):
					if self.direction.x > 0: 
						self.hitbox.right = sprite.hitbox.left
					if self.direction.x < 0: 
		 				self.hitbox.left = sprite.hitbox.right
					self.direction.x = 0

		if direction == 'vertical':
			for sprite in self.game.obstacle_sprites:
				if sprite.hitbox.colliderect(self.hitbox):
					if self.direction.y > 0: 
						self.hitbox.bottom = sprite.hitbox.top
					if self.direction.y < 0: 
		 				self.hitbox.top = sprite.hitbox.bottom
					self.direction.y = 0

	def update(self):
		self.input()
		self.movement()
		self.animate()
		self.attack_cooldown()
