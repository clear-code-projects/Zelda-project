<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Floor" tilewidth="64" tileheight="64" tilecount="396" columns="22">
 <image source="../graphics/Tiles/Floor.png" width="1408" height="1152"/>
</tileset>
