<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="SmallObjects" tilewidth="64" tileheight="64" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="8">
  <image width="64" height="64" source="../graphics/Grass/grass_1.png"/>
 </tile>
 <tile id="9">
  <image width="64" height="64" source="../graphics/Grass/grass_2.png"/>
 </tile>
 <tile id="10">
  <image width="64" height="64" source="../graphics/Grass/grass_3.png"/>
 </tile>
</tileset>
